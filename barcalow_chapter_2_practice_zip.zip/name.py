# Ada Lovelace is awesome, but Monty Python is the namesake of Python, so...

# What is your name?
name = "arthur, king of the britons"
print(name.title())

# What is your quest?
quest = "to seek the Holy Grail"
print(quest.upper())

# What is the air-speed velocity of an unladen swallow?
answer = "African or European swallow?"
print(answer.lower())

# .lower() is very useful for checking user input (that and .strip())