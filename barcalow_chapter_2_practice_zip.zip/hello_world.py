# I had to go back and do these afterwards...
message = "Hello Python world!"
print(message)

message = "and now message is something different :O"
print(message)

message = "woah so cool i don't even have to declare my variables"
print(message)

mesage = "Spelling \"message\" wrong doesn't throw an error, but PyCharm's spell-checker and refactor tool doesn't like it."
print(mesage)