# F-STRINGS!!!!

first_name = "James"
last_name = "Bond"

# Usually I use camelCase for variable names, but since I'm copying from the book (and it's Python), I'll use snake_case.
introduction = f"The name's {last_name.title()}. {first_name.title()} {last_name.title()}."
print(introduction)