# I prefer double quotes (almost always).
message = "Tea's ready."
print(message)

# message = 'The usage of apostrophes isn't quite as common as the usage of double quotes, so I should probably use single quotes.'
# print(message)

message = "By using an editor's auto-quote feature, it's much more difficult to make mistakes with quotes."
print(message)