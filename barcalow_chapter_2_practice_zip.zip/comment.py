# I
# love
# comments

print("there's a lot more to see in the code than in the console")

# especially witty ones

# In almost all of my programs, I hide asides or Easter eggs or joking comments in the code.
# I made a small fetch quest game once and named most of the characters after video game, book, and TV show characters
# Inside the code, I left comments detailing the names for each of them.

# and with that, I'm finished with chapter two!